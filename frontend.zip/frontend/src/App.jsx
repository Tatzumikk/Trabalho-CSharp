import './App.css';
import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { AlertProvider } from './contexts/alert';

import Autor from './pages/autor/Index';
import Livro from './pages/livro/Index';
import Pedido from './pages/pedido/Index';
import Cliente from './pages/cliente/Index';
import Editora from './pages/editora/Index';

function App() {
  return (
    <>
      <AlertProvider>
        <Routes>
          <Route path='/autor' element={<Autor />} />
          <Route path='/livro' element={<Livro />} />
          <Route path='/pedido' element={<Pedido />} />
          <Route path='/cliente' element={<Cliente />} />
          <Route path='/editora' element={<Editora />} />
        </Routes>
      </AlertProvider>
    </>
  );
}

export default App;