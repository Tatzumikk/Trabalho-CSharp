function FooterApp(){
    return(
        <footer class="main-footer">Rodapé</footer>
    );
}
 export default FooterApp;