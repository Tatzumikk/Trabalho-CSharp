function HeaderApp(){
    return(
      <header class="main-head">
       <h1>Sistema de Gerenciamento de Produtos</h1> 
        </header>  
    );
}

export default HeaderApp;

