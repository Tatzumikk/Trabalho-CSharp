import React, { useEffect, useState } from 'react';
import { useNavigate } from "react-router-dom";
import Style from "./Style.css"

export default function Autor() {

    return (
        <>
            <div className='body'>
                <h1 className='titulo'>CRUD do Autor</h1>

                <div className='cards'>
                    <div className='card'>
                        <h4 className='tituloCard'>Procure por um Autor - GET</h4>
                        <input className='inputCard' type="number" placeholder='Insira o ID do Autor' />
                    </div>
                    <div className='card'>
                        <h4 className='tituloCard'>Insira um Autor - POST</h4>
                        <input className='inputCard' type="number" placeholder='Insira o ID do Autor' />
                        <input className='inputCard' type="text" placeholder='Insira o nome do Autor' />
                    </div>
                    <div className='card'>
                        <h4 className='tituloCard'>Atualize um Autor - UPDATE</h4>
                        <input className='inputCard' type="number" placeholder='Insira o ID do Autor' />
                        <input className='inputCard' type="text" placeholder='Insira o nome do Autor' />
                    </div>
                    <div className='card'>
                        <h4 className='tituloCard'>Delete um Autor - DELETE</h4>
                        <input className='inputCard' type="number" placeholder='Insira o ID do Autor' />
                    </div>
                </div>
            </div>
        </>
    );
}