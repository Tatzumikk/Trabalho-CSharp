import React, { useEffect, useState } from 'react';
import { useNavigate } from "react-router-dom";
import "./Style.css"

export default function Pedido() {

    return (
        <>
            <div className='body'>
                <h1 className='titulo'>CRUD do Pedido</h1>

                <div className='cards'>
                    <div className='card'>
                        <h4 className='tituloCard'>Procure por um Pedido - GET</h4>
                        <input className='inputCard' type="number" placeholder='Insira o ID do Pedido' />
                    </div>
                    <div className='card'>
                        <h4 className='tituloCard'>Insira um Pedido - POST</h4>
                        <input className='inputCard' type="number" placeholder='Insira o ID do Pedido' />
                        <input className='inputCard' type="text" placeholder='Insira o cliente do Pedido' />
                        <input className='inputCard' type="text" placeholder='Insira o livro do Pedido' />
                    </div>
                    <div className='card'>
                        <h4 className='tituloCard'>Atualize um Pedido - UPDATE</h4>
                        <input className='inputCard' type="number" placeholder='Insira o ID do Pedido' />
                        <input className='inputCard' type="text" placeholder='Insira o cliente do Pedido' />
                        <input className='inputCard' type="text" placeholder='Insira o livro do Pedido' />
                    </div>
                    <div className='card'>
                        <h4 className='tituloCard'>Delete um Pedido - DELETE</h4>
                        <input className='inputCard' type="number" placeholder='Insira o ID do Pedido' />
                    </div>
                </div>
            </div>
        </>
    );
}